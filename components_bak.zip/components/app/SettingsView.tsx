"use client"

import { useState, useEffect, FormEvent, useRef } from "react"
import { createPortal } from "react-dom"
import { supabase } from "@/lib/supabase"
import { User } from "@supabase/supabase-js"
import { Capacitor } from "@capacitor/core"
import { App as CapApp } from "@capacitor/app"
import { StatusBar, Style } from "@capacitor/status-bar"
import { PushNotifications } from "@capacitor/push-notifications"

// UI Imports
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger, DialogDescription } from "@/components/ui/dialog"
import { Plus, UserPlus, Eye, EyeOff, Target, ShoppingCart, Lock, Trash2, Pencil, PiggyBank, X, Info, Wallet, ArrowLeft, Receipt, Loader2, ArrowDown, ListChecks, CheckCircle2, Goal, TrendingUp, ArrowDownRight, User as UserIcon, Camera, LogOut, AlertTriangle, Shield, CreditCard, MapPin, Sparkles, ChevronRight, Check, Moon, CloudOff, Share2, Star, Globe, MessageCircle, UserMinus } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"

// ⚡ REAL IMPORTS (Using your existing files)
import { SidebarLayout } from "@/components/ui/SidebarLayout"
import { ListDetail } from "@/components/app/ListDetail"
import { ShoppingList } from "@/components/app/ShoppingList"
import { Finance } from "@/components/app/Finance"
import { HomeOverview } from "@/components/app/HomeOverview"
import { OnboardingWizard } from "@/components/app/OnboardingWizard"
import { HouseholdSyncDialog } from "@/components/app/HouseholdSyncDialog"
import { NotificationBell } from "@/components/app/NotificationBell"
import { Household, List } from "@/lib/types"
import { getCurrencySymbol, EXPENSE_CATEGORIES, COUNTRIES, CURRENCIES } from "@/lib/constants"
import { Haptics, ImpactStyle, NotificationType } from "@capacitor/haptics"
import { clearCache, getCacheSize } from "@/lib/offline"


// --- TYPES ---
type ListWithSummary = List & {
    pending_items?: number; estimated_cost?: number;
    active_goals?: number; target_amount?: number; saved_amount?: number;
    total_goals?: number; completed_goals?: number;
};
type ListSummary = {
    list_id: string; total_pending_items?: number; estimated_cost?: number;
    total_active_goals?: number; total_target_amount?: number; total_saved_amount?: number;
    total_goals?: number; completed_goals?: number;
};

// --- MOCK SidebarLayout ---
const SidebarLayout = ({ children, activeTab, setActiveTab }: { children: React.ReactNode, activeTab: string, setActiveTab: (t: string) => void, [key: string]: any }) => (
    <div className="flex flex-col h-screen bg-slate-50 font-sans">
        <div className="flex-1 overflow-y-auto overflow-x-hidden pb-20">{children}</div>
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 p-2 flex justify-around z-50">
            {['home', 'wishlist', 'shopping', 'finance'].map((tab: string) => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`p-2 rounded-lg capitalize text-xs font-bold flex flex-col items-center gap-1 transition-colors ${activeTab === tab ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400 hover:text-slate-600'}`}
                >
                    <span className="w-2 h-2 rounded-full bg-current opacity-50"></span>
                    {tab}
                </button>
            ))}
        </div>
    </div>
);

// --- AUXILIARY HELPER COMPONENTS (Required by ListManager/SettingsView) ---

function ConfirmDialog({ isOpen, onOpenChange, title, description, onConfirm }: { isOpen: boolean, onOpenChange: (open: boolean) => void, title: string, description: string, onConfirm: () => void }) {
    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-sm rounded-2xl">
                <DialogHeader><DialogTitle>{title}</DialogTitle></DialogHeader>
                <div className="text-sm text-slate-500 py-2">{description}</div>
                <DialogFooter className="flex gap-2 sm:justify-end">
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button variant="destructive" onClick={() => { onConfirm(); onOpenChange(false); }}>Confirm</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

function PortalFAB({ onClick, className, icon: Icon }: any) {
    const [mounted, setMounted] = useState(false);
    useEffect(() => setMounted(true), []);
    if (!mounted) return null;
    return createPortal(
        <div className="fixed bottom-24 right-4 md:bottom-8 md:right-8 z-[100] animate-in zoom-in duration-300">
            <Button onClick={onClick} className={`${className} shadow-2xl border-4 border-white/20 active:scale-90 transition-transform`}>
                <Icon className="w-8 h-8" />
            </Button>
        </div>,
        document.body
    );
}

function PullToRefresh({ onRefresh, children }: { onRefresh: () => Promise<void>, children: React.ReactNode }) {
    const [startY, setStartY] = useState(0);
    const [pullDistance, setPullDistance] = useState(0);
    const [refreshing, setRefreshing] = useState(false);
    const threshold = 80;

    const handleTouchStart = (e: React.TouchEvent) => {
        if (window.scrollY === 0) setStartY(e.touches[0].clientY);
    };

    const handleTouchMove = (e: React.TouchEvent) => {
        if (startY > 0 && window.scrollY === 0) {
            const currentY = e.touches[0].clientY;
            const dist = Math.max(0, currentY - startY);
            setPullDistance(dist > threshold ? threshold + (dist - threshold) * 0.3 : dist);
        }
    };

    const handleTouchEnd = async () => {
        if (pullDistance >= threshold) {
            setRefreshing(true);
            setPullDistance(threshold);
            await onRefresh();
            setRefreshing(false);
        }
        setStartY(0);
        setPullDistance(0);
    };

    return (
        <div onTouchStart={handleTouchStart} onTouchMove={handleTouchMove} onTouchEnd={handleTouchEnd}>
            <div style={{ height: pullDistance, transition: refreshing ? 'height 0.2s' : 'none' }} className="w-full overflow-hidden flex items-center justify-center bg-slate-50">
                <div className={`transition-transform ${pullDistance > threshold / 2 ? 'rotate-180' : ''}`}>
                    {refreshing ? <Loader2 className="w-6 h-6 animate-spin text-indigo-600" /> : <ArrowDown className="w-6 h-6 text-slate-400" />}
                </div>
            </div>
            {children}
        </div>
    );
}

// ⚡ IMAGE COMPRESSION (Needed by SettingsView)
const compressImage = (file: File): Promise<Blob> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.src = URL.createObjectURL(file);
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) { reject(new Error("Canvas not supported")); return; }
            const MAX_SIZE = 800;
            let width = img.width; let height = img.height;
            if (width > height) { if (width > MAX_SIZE) { height *= MAX_SIZE / width; width = MAX_SIZE; } }
            else { if (height > MAX_SIZE) { width *= MAX_SIZE / height; height = MAX_SIZE; } }
            canvas.width = width; canvas.height = height;
            ctx.drawImage(img, 0, 0, width, height);
            canvas.toBlob((blob) => {
                if (!blob) { reject(new Error("Compression failed")); return; }
                resolve(blob);
            }, 'image/jpeg', 0.7);
        };
        img.onerror = (error) => reject(error);
    });
}

function AlertDialog({ isOpen, onOpenChange, title, description }: { isOpen: boolean, onOpenChange: (open: boolean) => void, title: string, description: string }) {
    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-sm rounded-2xl">
                <DialogHeader><DialogTitle>{title}</DialogTitle><DialogDescription>{description}</DialogDescription></DialogHeader>
                <DialogFooter><Button onClick={() => onOpenChange(false)} className="w-full bg-slate-900 text-white">OK</Button></DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

// --- CURRENCY/COUNTRY SELECTORS (Used by SettingsView) ---

function CurrencySelector({ value, onSelect, disabled }: { value: string, onSelect: (c: string) => void, disabled: boolean }) {
    const [isOpen, setIsOpen] = useState(false);
    const selectedCurrency = CURRENCIES.find(c => c.code === value) || CURRENCIES[0];

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <div
                onClick={() => !disabled && setIsOpen(true)}
                className={`flex items-center justify-between p-4 bg-white active:bg-slate-50 transition-colors cursor-pointer ${disabled ? 'opacity-50 pointer-events-none' : ''}`}
            >
                <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-xl bg-lime-50 flex items-center justify-center text-lime-600">
                        <CreditCard className="w-5 h-5" />
                    </div>
                    <div>
                        <p className="text-sm font-bold text-slate-800">Currency</p>
                        <p className="text-xs text-slate-500">{selectedCurrency.name} ({selectedCurrency.symbol})</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-600">{value}</span>
                    <ChevronRight className="w-4 h-4 text-slate-300" />
                </div>
            </div>

            <DialogContent className="max-w-sm rounded-3xl max-h-[85vh] overflow-hidden flex flex-col">
                <DialogHeader>
                    <DialogTitle>Select Currency</DialogTitle>
                    <DialogDescription>Choose your primary household currency.</DialogDescription>
                </DialogHeader>
                <div className="flex-1 overflow-y-auto p-1 grid grid-cols-2 gap-3 pt-2">
                    {CURRENCIES.map(c => (
                        <button
                            key={c.code}
                            onClick={() => { onSelect(c.code); setIsOpen(false); }}
                            className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all active:scale-95 ${value === c.code ? 'bg-lime-50 border-lime-500 shadow-sm ring-1 ring-lime-500' : 'bg-white border-slate-100 hover:border-slate-300'}`}
                        >
                            <span className="text-2xl font-bold text-slate-800">{c.symbol}</span>
                            <span className="text-sm font-bold text-slate-600">{c.code}</span>
                            <span className="text-[10px] text-slate-400 text-center leading-tight">{c.name}</span>
                        </button>
                    ))}
                </div>
            </DialogContent>
        </Dialog>
    )
}

function CountrySelector({ value, onSelect, disabled }: { value: string, onSelect: (c: string) => void, disabled: boolean }) {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <div
                onClick={() => !disabled && setIsOpen(true)}
                className={`flex items-center justify-between p-4 bg-white active:bg-slate-50 transition-colors cursor-pointer ${disabled ? 'opacity-50 pointer-events-none' : ''}`}
            >
                <div className="flex items-center gap-4">
                    <div className="h-10 w-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500">
                        <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                        <p className="text-sm font-bold text-slate-800">Country</p>
                        <p className="text-xs text-slate-500">Region settings</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-600 truncate max-w-[100px]">{value}</span>
                    <ChevronRight className="w-4 h-4 text-slate-300" />
                </div>
            </div>

            <DialogContent className="max-w-sm rounded-3xl max-h-[85vh] overflow-hidden flex flex-col">
                <DialogHeader>
                    <DialogTitle>Select Country</DialogTitle>
                </DialogHeader>
                <div className="flex-1 overflow-y-auto space-y-1 p-1">
                    {COUNTRIES.map(c => (
                        <button
                            key={c}
                            onClick={() => { onSelect(c); setIsOpen(false); }}
                            className={`w-full p-3 rounded-xl flex items-center justify-between transition-colors ${value === c ? 'bg-lime-50 text-lime-700 font-bold' : 'hover:bg-slate-50 text-slate-700'}`}
                        >
                            <span>{c}</span>
                            {value === c && <Check className="w-4 h-4" />}
                        </button>
                    ))}
                </div>
            </DialogContent>
        </Dialog>
    )
}

// ⚡ SETTINGS VIEW (With Editability Fixes)
export function SettingsView({ user, household, onSettingsChange }: { user: User, household: Household & { invite_code?: string }, onSettingsChange: () => void }) {
    const [loading, setLoading] = useState(false);
    const [uploading, setUploading] = useState(false);
    const [members, setMembers] = useState<any[]>([]);
    const [verifyOpen, setVerifyOpen] = useState(false);
    const [verifyType, setVerifyType] = useState<'leave' | 'delete'>('leave');
    const [verifyInput, setVerifyInput] = useState("");
    const [appVersion, setAppVersion] = useState("1.0.0");
    const [cacheSize, setCacheSize] = useState("0 KB");

    const [rating, setRating] = useState(0);
    const [removeMemberId, setRemoveMemberId] = useState<string | null>(null);

    const [name, setName] = useState(user.user_metadata?.full_name || "");
    const [avatarUrl, setAvatarUrl] = useState(user.user_metadata?.avatar_url || "");
    const [hhForm, setHhForm] = useState({
        name: household.name,
        country: household.country || "Nigeria",
        currency: household.currency || "NGN",
        avatar_url: household.avatar_url || ""
    });

    const joinedDate = new Date(user.created_at || Date.now()).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    const userFileRef = useRef<HTMLInputElement>(null);
    const householdFileRef = useRef<HTMLInputElement>(null);

    // Derived
    const amIAdmin = members.length > 0 ? (members.find(m => m.id === user.id)?.is_owner ?? false) : true;

    // Load Data
    useEffect(() => {
        async function init() {
            if (Capacitor.isNativePlatform()) {
                try { const info = await CapApp.getInfo(); setAppVersion(`${info.version} (${info.build})`); } catch (e) { }
            }
            const size = await getCacheSize();
            setCacheSize(size);
            const { data: ratingData } = await supabase.from('app_ratings').select('rating').eq('user_id', user.id).single();
            if (ratingData) setRating(ratingData.rating);
        }
        init();

        async function getMembers() {
            const { data } = await supabase.rpc('get_household_members_safe', { target_household_id: household.id });
            if (data) {
                setMembers(data.map((m: any) => ({ id: m.user_id, is_owner: m.is_owner, email: m.email, name: m.full_name || m.email?.split('@')[0] })));
            } else { setMembers([{ id: user.id, name: 'Me', is_owner: true }]); }
        }
        getMembers();
    }, [household.id, user.id]);

    const triggerHaptic = async (style: ImpactStyle = ImpactStyle.Light) => {
        if (Capacitor.isNativePlatform()) { try { await Haptics.impact({ style }); } catch (e) { } }
    };
    const triggerNotificationHaptic = async (type: NotificationType) => {
        if (Capacitor.isNativePlatform()) { try { await Haptics.notification({ type }); } catch (e) { } }
    }

    // --- ACTIONS ---
    const handleUserImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0]; if (!file) return;
        setUploading(true);
        try {
            const compressed = await compressImage(file);
            const path = `${user.id}/avatar-${Date.now()}.jpg`;
            await supabase.storage.from('images').upload(path, compressed);
            const { data } = supabase.storage.from('images').getPublicUrl(path);
            await supabase.auth.updateUser({ data: { avatar_url: data.publicUrl } });
            setAvatarUrl(data.publicUrl);
            triggerNotificationHaptic(NotificationType.Success);
            onSettingsChange();
        } catch (err: any) { alert(err.message); } finally { setUploading(false); }
    };

    const handleHouseholdImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!amIAdmin) return;
        const file = e.target.files?.[0]; if (!file) return;
        setUploading(true);
        try {
            const compressed = await compressImage(file);
            const path = `household-${household.id}/icon-${Date.now()}.jpg`;
            await supabase.storage.from('images').upload(path, compressed);
            const { data } = supabase.storage.from('images').getPublicUrl(path);

            // Set local state immediately for preview
            setHhForm(prev => ({ ...prev, avatar_url: data.publicUrl }));

            // Save image URL to DB
            const { error } = await supabase.from('households').update({ avatar_url: data.publicUrl }).eq('id', household.id);
            if (error) throw error;

            triggerNotificationHaptic(NotificationType.Success);
            onSettingsChange();
        } catch (err: any) { alert(err.message); } finally { setUploading(false); }
    };

    const handleSaveProfile = async () => {
        setLoading(true); triggerHaptic(ImpactStyle.Medium);
        const { error } = await supabase.auth.updateUser({ data: { full_name: name } });
        setLoading(false);
        if (error) alert(error.message);
        else { triggerNotificationHaptic(NotificationType.Success); onSettingsChange(); }
    }

    const handleSaveHousehold = async () => {
        if (!amIAdmin) return;
        setLoading(true); triggerHaptic(ImpactStyle.Medium);
        // Save name, currency, country, and current avatar_url
        const { error } = await supabase.from('households').update({
            name: hhForm.name,
            country: hhForm.country,
            currency: hhForm.currency,
            avatar_url: hhForm.avatar_url
        }).eq('id', household.id);
        setLoading(false);
        if (error) alert(error.message);
        else { triggerNotificationHaptic(NotificationType.Success); onSettingsChange(); }
    }

    const handleShareApp = async () => {
        triggerHaptic(ImpactStyle.Medium);
        const url = 'https://listner.site/';
        const msg = 'Organize your household lists and expenses with ListNer!';
        if (Capacitor.isNativePlatform()) {
            await Share.share({ title: 'ListNer', text: msg, url: url, dialogTitle: 'Share with friends' });
        } else if (navigator.share) {
            await navigator.share({ title: 'ListNer', text: msg, url });
        } else {
            await navigator.clipboard.writeText(`${msg} ${url}`);
            alert("Link copied!");
        }
    }

    const handleClearCache = async () => { triggerHaptic(ImpactStyle.Medium); await clearCache(); setCacheSize("0 KB"); alert("Cache cleared."); }
    const handleRateApp = async (stars: number) => { setRating(stars); triggerHaptic(ImpactStyle.Medium); const { error } = await supabase.from('app_ratings').upsert({ user_id: user.id, rating: stars, updated_at: new Date().toISOString() }, { onConflict: 'user_id' }); }

    const triggerVerification = (type: 'leave' | 'delete') => { /* ... existing logic ... */ }
    const handleVerifiedAction = async () => { /* ... existing logic ... */ }
    const confirmRemoveMember = async () => { /* ... */ }
    const handleCopyInvite = async () => { /* ... */ }

    return (
        <div className="max-w-2xl mx-auto pb-24 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <Tabs defaultValue="profile" className="w-full">

                {/* 1. TAB HEADER */}
                <TabsList className="grid w-full grid-cols-3 mb-6 bg-slate-100 p-1 rounded-2xl h-12">
                    <TabsTrigger value="profile" onClick={() => triggerHaptic()} className="rounded-xl data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=active]:shadow-sm font-bold text-xs"><UserIcon className="w-4 h-4 mr-2" /> Profile</TabsTrigger>
                    <TabsTrigger value="household" onClick={() => triggerHaptic()} className="rounded-xl data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=active]:shadow-sm font-bold text-xs"><Home className="w-4 h-4 mr-2" /> Household</TabsTrigger>
                    <TabsTrigger value="app" onClick={() => triggerHaptic()} className="rounded-xl data-[state=active]:bg-white data-[state=active]:text-slate-900 data-[state=active]:shadow-sm font-bold text-xs"><Sparkles className="w-4 h-4 mr-2" /> App</TabsTrigger>
                </TabsList>

                {/* 2. PROFILE TAB (Clean White) */}
                <TabsContent value="profile" className="space-y-6">
                    <div className="bg-white rounded-3xl p-8 flex flex-col items-center shadow-sm border border-slate-100 text-center">
                        <div className="relative group cursor-pointer mb-4" onClick={() => userFileRef.current?.click()}>
                            <div className="h-24 w-24 rounded-full bg-slate-50 border-4 border-white shadow-lg overflow-hidden flex items-center justify-center">
                                {avatarUrl ? <img src={avatarUrl} className="w-full h-full object-cover" alt="Profile" /> : <div className="w-full h-full flex items-center justify-center bg-slate-100 text-3xl font-bold text-slate-400">{name?.[0]}</div>}
                                {uploading && <div className="absolute inset-0 bg-black/40 flex items-center justify-center"><Loader2 className="w-6 h-6 text-white animate-spin" /></div>}
                            </div>
                            <div className="absolute bottom-0 right-0 bg-slate-900 text-white p-2 rounded-full border-4 border-white shadow-sm"><Camera className="w-3.5 h-3.5" /></div>
                            <input type="file" ref={userFileRef} hidden accept="image/*" onChange={handleUserImageUpload} />
                        </div>
                        <h2 className="text-xl font-bold text-slate-900">{name || "User"}</h2>
                        <p className="text-xs text-slate-400 font-medium mb-3">{user.email}</p>
                        <Badge variant="secondary" className="bg-lime-100 text-lime-700 hover:bg-lime-100 border-none font-medium">Member since {joinedDate.split(' ')[2]}</Badge>
                    </div>

                    <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 space-y-4">
                        <div className="space-y-1">
                            <Label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">Display Name</Label>
                            <Input value={name} onChange={e => setName(e.target.value)} className="h-12 rounded-xl bg-slate-50 border-slate-200 focus:bg-white transition-all text-sm font-medium" />
                        </div>
                        <Button onClick={handleSaveProfile} disabled={loading} className="w-full h-12 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold">Save Changes</Button>
                    </div>

                    <Button variant="ghost" className="w-full text-rose-500 hover:bg-rose-50 h-12 rounded-xl text-sm font-bold" onClick={async () => { triggerHaptic(ImpactStyle.Medium); await supabase.auth.signOut(); window.location.reload(); }}>
                        <LogOut className="w-4 h-4 mr-2" /> Sign Out
                    </Button>
                </TabsContent>

                {/* 3. HOUSEHOLD TAB (RESTORED IMAGE & CLEAN DESIGN) */}
                <TabsContent value="household" className="space-y-6">
                    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden divide-y divide-slate-50">
                        {/* ICON / NAME / IMAGE UPLOAD SECTION (EDITABLE) */}
                        <div className="p-4 flex items-center gap-4">
                            <div className="relative cursor-pointer flex-shrink-0" onClick={() => amIAdmin && householdFileRef.current?.click()}>
                                <div className="h-14 w-14 rounded-xl bg-slate-50 border border-slate-100 overflow-hidden flex items-center justify-center">
                                    {hhForm.avatar_url ? <img src={hhForm.avatar_url} className="w-full h-full object-cover" alt="Household Icon" /> : <Home className="w-6 h-6 text-slate-300" />}
                                </div>
                                {amIAdmin && <div className="absolute -bottom-1 -right-1 bg-slate-900 text-white p-1 rounded-full border border-white"><Camera className="w-3.5 h-3.5" /></div>}
                                <input type="file" ref={householdFileRef} hidden accept="image/*" onChange={handleHouseholdImageUpload} />
                            </div>

                            <div className="flex-1">
                                <Label className="text-xs font-bold text-slate-500 uppercase">Household Name</Label>
                                <Input
                                    value={hhForm.name}
                                    onChange={e => setHhForm({ ...hhForm, name: e.target.value })}
                                    disabled={!amIAdmin}
                                    className="h-9 mt-1 bg-transparent border-none shadow-none p-0 text-sm font-bold text-slate-800 focus-visible:ring-0 placeholder:text-slate-300"
                                    placeholder="My Home"
                                />
                            </div>
                            {amIAdmin && <Button size="sm" onClick={handleSaveHousehold} disabled={loading} className="bg-slate-900 text-white rounded-xl">Save</Button>}
                        </div>

                        {/* Currency Selector */}
                        <CurrencySelector
                            value={hhForm.currency}
                            onSelect={c => setHhForm({ ...hhForm, currency: c })}
                            disabled={!amIAdmin}
                        />

                        {/* Country Selector */}
                        <CountrySelector
                            value={hhForm.country || "Nigeria"}
                            onSelect={c => setHhForm({ ...hhForm, country: c })}
                            disabled={!amIAdmin}
                        />
                    </div>

                    {/* Member Management */}
                    <div className="space-y-2">
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-2">Members ({members.length})</h3>
                        <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden divide-y divide-slate-50">
                            <div className="p-4 flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <div className="h-10 w-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400"><Users className="w-5 h-5" /></div>
                                    <div><p className="text-sm font-bold text-slate-800">Invite Code</p><p className="text-xs text-slate-500">{household.invite_code}</p></div>
                                </div>
                                <Button size="sm" variant="outline" onClick={() => handleCopyInvite()} className="gap-2 h-8 rounded-lg text-xs font-bold text-lime-600 border-lime-200">
                                    <Share2 className="w-3.5 h-3.5" /> Invite
                                </Button>
                            </div>
                            {members.map((m) => (
                                <div key={m.id} className="p-4 flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <div className="h-9 w-9 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-500 text-xs">{m.name?.[0]}</div>
                                        <div><p className="text-sm font-bold text-slate-800">{m.name}</p><p className="text-[10px] text-slate-400">{m.is_owner ? 'Admin' : 'Member'}</p></div>
                                    </div>
                                    {m.is_owner && <Shield className="w-4 h-4 text-lime-500 fill-lime-100" />}
                                    {amIAdmin && !m.is_owner && <Button variant="ghost" size="sm" onClick={() => setRemoveMemberId(m.id)} className="p-2 text-rose-400 hover:bg-rose-50 rounded-full"><UserMinus className="w-4 h-4" /></Button>}
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="space-y-2 pt-4">
                        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-2">Danger Zone</h3>
                        <div className="bg-rose-50/50 rounded-3xl border border-rose-100 overflow-hidden divide-y divide-rose-100">
                            <button onClick={() => triggerVerification('leave')} className="w-full p-4 flex items-center justify-between hover:bg-rose-100/50 transition-colors text-left">
                                <div><p className="text-sm font-bold text-rose-700">Leave Household</p><p className="text-xs text-rose-500">Sign out of this space.</p></div>
                                <LogOut className="w-5 h-5 text-rose-400" />
                            </button>
                        </div>
                    </div>
                </TabsContent>

                {/* --- 4. APP TAB (Consistent) --- */}
                <TabsContent value="app" className="space-y-6">
                    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden divide-y divide-slate-50">
                        {/* Dark Mode */}
                        <div className="p-4 flex items-center justify-between opacity-60">
                            <div className="flex items-center gap-4">
                                <div className="h-10 w-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-500"><Moon className="w-5 h-5" /></div>
                                <div><p className="text-sm font-bold text-slate-800">Dark Mode</p><p className="text-xs text-slate-500">Coming Soon</p></div>
                            </div>
                            <Switch disabled checked={false} />
                        </div>
                        {/* Cache */}
                        <div className="p-4 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <div className="h-10 w-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-500"><CloudOff className="w-5 h-5" /></div>
                                <div><p className="text-sm font-bold text-slate-800">Offline Data</p><p className="text-xs text-slate-500">{cacheSize}</p></div>
                            </div>
                            <Button size="sm" variant="ghost" onClick={handleClearCache} className="text-xs h-8 font-bold text-slate-600">Clear</Button>
                        </div>
                    </div>

                    {/* Share Button (Lime) */}
                    <button
                        onClick={handleShareApp}
                        className="w-full p-4 rounded-3xl shadow-lg shadow-lime-100 bg-lime-500 text-slate-900 flex items-center justify-between group active:scale-[0.98] transition-all"
                    >
                        <div className="flex items-center gap-4">
                            <div className="p-2 bg-white/30 rounded-xl backdrop-blur-sm"><Share2 className="w-5 h-5" /></div>
                            <div className="text-left">
                                <span className="block text-sm font-bold">Share App</span>
                                <span className="block text-[10px] opacity-70 font-medium">Invite friends to ListNer</span>
                            </div>
                        </div>
                        <ChevronRight className="w-5 h-5 opacity-50 group-hover:translate-x-1 transition-transform" />
                    </button>

                    {/* Support Links */}
                    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden divide-y divide-slate-50">
                        {/* Rating */}
                        <div className="p-4 flex flex-col gap-3">
                            <div className="flex items-center gap-4">
                                <div className="h-10 w-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-500"><Star className="w-5 h-5" /></div>
                                <div><p className="text-sm font-bold text-slate-800">Rate Us</p><p className="text-xs text-slate-500">Love the app?</p></div>
                            </div>
                            {/* Rating Stars (Simplified) */}
                            <div className="flex justify-between px-2 pt-1">
                                <Star className={`w-8 h-8 cursor-pointer transition-all ${rating >= 1 ? 'fill-amber-400 text-amber-400 scale-110' : 'text-slate-200 hover:text-amber-200'}`} onClick={() => handleRateApp(1)} />
                                <Star className={`w-8 h-8 cursor-pointer transition-all ${rating >= 2 ? 'fill-amber-400 text-amber-400 scale-110' : 'text-slate-200 hover:text-amber-200'}`} onClick={() => handleRateApp(2)} />
                                <Star className={`w-8 h-8 cursor-pointer transition-all ${rating >= 3 ? 'fill-amber-400 text-amber-400 scale-110' : 'text-slate-200 hover:text-amber-200'}`} onClick={() => handleRateApp(3)} />
                                <Star className={`w-8 h-8 cursor-pointer transition-all ${rating >= 4 ? 'fill-amber-400 text-amber-400 scale-110' : 'text-slate-200 hover:text-amber-200'}`} onClick={() => handleRateApp(4)} />
                                <Star className={`w-8 h-8 cursor-pointer transition-all ${rating >= 5 ? 'fill-amber-400 text-amber-400 scale-110' : 'text-slate-200 hover:text-amber-200'}`} onClick={() => handleRateApp(5)} />
                            </div>
                        </div>

                        <a href="https://listner.site" target="_blank" rel="noreferrer" className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                            <div className="flex items-center gap-4">
                                <div className="h-10 w-10 rounded-xl bg-cyan-50 flex items-center justify-center text-cyan-600"><Globe className="w-5 h-5" /></div>
                                <div><p className="text-sm font-bold text-slate-800">Visit Website</p><p className="text-xs text-slate-500">Listner.site</p></div>
                            </div>
                            <ChevronRight className="w-4 h-4 text-slate-300" />
                        </a>

                        <a href="mailto:aliyuiliyasu15@hotmail.com?subject=ListNer%20Support" className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                            <div className="flex items-center gap-4">
                                <div className="h-10 w-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600"><MessageCircle className="w-5 h-5" /></div>
                                <div><p className="text-sm font-bold text-slate-800">Contact Support</p><p className="text-xs text-slate-500">Get help</p></div>
                            </div>
                            <ChevronRight className="w-4 h-4 text-slate-300" />
                        </a>
                    </div>

                    {/* Footer */}
                    <div className="text-center pt-6 pb-2">
                        <p className="text-xs font-bold text-slate-400">© 2025 ListNer Inc.</p>
                        <p className="text-[10px] text-slate-300 font-mono mt-1">v{appVersion}</p>
                    </div>
                </TabsContent>
            </Tabs>

            {/* Dialogs (Placeholder for Confirmation Dialogs) */}
            <ConfirmDialog isOpen={verifyOpen} onOpenChange={(o) => !o && setVerifyOpen(false)} title="Confirm Action" description="Are you sure?" onConfirm={handleVerifiedAction} />
            <AlertDialog isOpen={false} onOpenChange={() => { }} title={""} description={""} />
        </div>
    )
}