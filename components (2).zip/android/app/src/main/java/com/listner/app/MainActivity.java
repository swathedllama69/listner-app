package com.listner.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
